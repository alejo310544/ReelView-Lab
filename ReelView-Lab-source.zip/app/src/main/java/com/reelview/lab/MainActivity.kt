package com.reelview.lab

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.Chronometer
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var timer: Chronometer
    private lateinit var linkInput: EditText
    private lateinit var sessionsText: TextView
    private var sessions = 0
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 35, 28, 35)
            setBackgroundColor(Color.rgb(15, 23, 42))
        }

        fun makeText(value: String, size: Float, color: Int): TextView =
            TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
            }

        layout.addView(makeText("▶ REELVIEW LAB", 27f, Color.WHITE))
        layout.addView(makeText("Laboratorio de reproducción", 15f, Color.LTGRAY))

        val subtitle = makeText("Pruebas de Reels de Facebook", 19f, Color.WHITE)
        subtitle.setPadding(0, 35, 0, 15)
        layout.addView(subtitle)

        linkInput = EditText(this).apply {
            hint = "Pega aquí el enlace del Reel"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setPadding(15, 12, 15, 12)
            setBackgroundColor(Color.rgb(45, 55, 72))
        }
        layout.addView(linkInput)

        val openButton = Button(this).apply { text = "ABRIR REEL" }
        layout.addView(openButton)

        timer = Chronometer(this).apply {
            textSize = 34f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 30, 0, 20)
        }
        layout.addView(timer)

        val startButton = Button(this).apply { text = "INICIAR PRUEBA" }
        layout.addView(startButton)

        val stopButton = Button(this).apply { text = "FINALIZAR PRUEBA" }
        layout.addView(stopButton)

        sessionsText = makeText("Sesiones registradas: 0", 17f, Color.WHITE)
        sessionsText.setPadding(0, 30, 0, 10)
        layout.addView(sessionsText)

        layout.addView(
            makeText(
                "El cronómetro registra tiempo de prueba local; " +
                    "no representa visualizaciones oficiales de Facebook.",
                12f,
                Color.LTGRAY
            )
        )

        openButton.setOnClickListener {
            val address = linkInput.text.toString().trim()
            val uri = Uri.parse(address)
            val host = uri.host?.lowercase().orEmpty()
            val validHost = host == "facebook.com" ||
                host.endsWith(".facebook.com") ||
                host == "fb.watch"

            if (uri.scheme == "https" && validHost) {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (_: Exception) {
                    Toast.makeText(this, "No se pudo abrir el enlace", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(
                    this,
                    "Introduce un enlace HTTPS válido de Facebook",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        startButton.setOnClickListener {
            if (!running) {
                timer.base = SystemClock.elapsedRealtime()
                timer.start()
                running = true
            }
        }

        stopButton.setOnClickListener {
            if (running) {
                timer.stop()
                running = false
                sessions++
                sessionsText.text = "Sesiones registradas: $sessions"
            }
        }

        setContentView(
            ScrollView(this).apply {
                addView(
                    layout,
                    ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                )
            }
        )
    }
}
